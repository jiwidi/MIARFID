Based on

* https://pytorch.org/tutorials/intermediate/reinforcement_q_learning.html
* https://github.com/openai/baselines/blob/edb52c22a5e14324304a491edc0f91b6cc07453b/baselines/common/atari_wrappers.py
*