import os

os.system('mkdir data/')
os.system('wget https://www.dropbox.com/s/sakfqp6o8pbgasm/data.tgz -P data/')
os.system('tar xvzf data/data.tgz -C data/')