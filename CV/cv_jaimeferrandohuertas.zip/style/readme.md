## Style transfer

Run 'python transfer.py'


Content image

![UPV](images/upv.png)

Style image

![Wave](images/style.png)

Result image

![Result](resultstyle.png)
