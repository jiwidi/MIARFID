#

Both assigments are filled with 1 model only. Model achieves >97% acc with less than 100K parameters.